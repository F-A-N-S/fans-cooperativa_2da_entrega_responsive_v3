-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: fans_cooperativa
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `Administrador`
--

DROP TABLE IF EXISTS `Administrador`;
/*!50001 DROP VIEW IF EXISTS `Administrador`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Administrador` AS SELECT 
 1 AS `id_Administrador`,
 1 AS `Nombre`,
 1 AS `Apellido`,
 1 AS `Usuario`,
 1 AS `Correo`,
 1 AS `Contrasena`,
 1 AS `estado_aprobacion`,
 1 AS `fecha_registro`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Comprobantes_Pago`
--

DROP TABLE IF EXISTS `Comprobantes_Pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comprobantes_Pago` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(100) NOT NULL,
  `Fecha` date NOT NULL,
  `Monto` decimal(10,2) DEFAULT NULL,
  `Estado` enum('Pendiente','Aprobado','Rechazado') NOT NULL DEFAULT 'Pendiente',
  `Archivo` varchar(255) NOT NULL,
  `id_Residente` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Estado` (`Estado`),
  KEY `id_Residente` (`id_Residente`),
  KEY `Fecha` (`Fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comprobantes_Pago`
--

LOCK TABLES `Comprobantes_Pago` WRITE;
/*!40000 ALTER TABLE `Comprobantes_Pago` DISABLE KEYS */;
INSERT INTO `Comprobantes_Pago` VALUES (1,'Luz','2025-01-01',NULL,'Aprobado','uploads/comprobantes/comp_d2049b8c25746e64.jpg',1,'2025-10-15 14:59:44'),(2,'Luz','2025-01-01',NULL,'Pendiente','uploads/comprobantes/comp_534afdfb86d40973.jpg',1,'2025-10-15 18:51:58');
/*!40000 ALTER TABLE `Comprobantes_Pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Residente`
--

DROP TABLE IF EXISTS `Residente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Residente` (
  `id_Residente` bigint NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) NOT NULL,
  `Apellido` varchar(100) NOT NULL,
  `Cedula` varchar(50) DEFAULT NULL,
  `Correo` varchar(190) NOT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Contrasena` varchar(255) NOT NULL,
  `estado_aprobacion` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Residente`),
  UNIQUE KEY `Correo` (`Correo`),
  KEY `Correo_2` (`Correo`),
  KEY `estado_aprobacion` (`estado_aprobacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Residente`
--

LOCK TABLES `Residente` WRITE;
/*!40000 ALTER TABLE `Residente` DISABLE KEYS */;
INSERT INTO `Residente` VALUES (1,'Juan','Perez','12345678','juan1892956207@example.com','099123123','2025-01-01','$2y$10$w6fmMnE69DDapONQqcZBouMRVa3SlO4B6MJZJWLlzLTeqbTwvc1me',1,'2025-10-15 18:32:43'),(2,'queti','asdasd','12345678','admin@fans.test','12345678','2000-07-14','$2y$10$ltTgl4Zk3iw.rWpV6ur9cOThi4U5c01rE2quEY5yiK5IWBlQRKBxm',1,'2025-10-15 18:33:48'),(3,'Nicolas','pereyra','12345678','pereyranicolas417@gmail.com','12345678','2000-07-14','$2y$10$AnoWj0OUb2JpGJ4HiusAaODFOS8vA6WlpYZVI7SS3NLZGyoQsO9Fe',1,'2025-10-15 18:46:09'),(4,'Nicolas','pereyra','12345678','nicolaperey@hotmail.com','12345678','2000-07-14','$2y$10$/TdVPnuCTJvgkzr3KEVWJuUGG9N3HLN5oomEeVwaHCem1OVNy6rrG',0,'2025-10-15 22:21:10');
/*!40000 ALTER TABLE `Residente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `id_Administrador` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Apellido` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Usuario` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Correo` varchar(120) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Contrasena` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `estado_aprobacion` tinyint(1) DEFAULT '0',
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Administrador`),
  UNIQUE KEY `Usuario` (`Usuario`),
  UNIQUE KEY `Correo` (`Correo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (2,'Admin','Principal','admin','admin@fans.test','Admin123',1,'2025-09-12 18:43:29');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `user_role` enum('admin','residente') NOT NULL,
  `token` char(64) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `idx_user` (`user_id`,`user_role`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_tokens`
--

LOCK TABLES `auth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
INSERT INTO `auth_tokens` VALUES (1,2,'admin','3599ee526fcc4b1c48e3fc13c659bff74c4c08ba425a34fa46088923f1855711','2025-10-18 07:59:31','2025-10-17 19:59:31');
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comprobante`
--

DROP TABLE IF EXISTS `comprobante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comprobante` (
  `id_Comprobante` int NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Monto` decimal(10,2) DEFAULT NULL,
  `Estado` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pendiente',
  `Archivo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha_Subida` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_Residente` int NOT NULL,
  `id_Administrador` int DEFAULT NULL,
  PRIMARY KEY (`id_Comprobante`),
  KEY `id_Residente` (`id_Residente`),
  KEY `id_Administrador` (`id_Administrador`),
  CONSTRAINT `comprobante_ibfk_1` FOREIGN KEY (`id_Residente`) REFERENCES `residente` (`id_Residente`) ON DELETE CASCADE,
  CONSTRAINT `comprobante_ibfk_2` FOREIGN KEY (`id_Administrador`) REFERENCES `administrador` (`id_Administrador`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comprobante`
--

LOCK TABLES `comprobante` WRITE;
/*!40000 ALTER TABLE `comprobante` DISABLE KEYS */;
INSERT INTO `comprobante` VALUES (8,'Luz','2000-02-12',NULL,'Pendiente','uploads/comprobantes/comp_1760648786_73f46462b08d1723.jpg','2025-10-16 21:06:26',8,NULL),(9,'Luz','2000-02-12',NULL,'Pendiente','uploads/comprobantes/comp_1760649241_a9b0b0d5b556b53c.jpg','2025-10-16 21:14:01',8,NULL),(10,'Luz','2000-02-12',NULL,'Pendiente','uploads/comprobantes/comp_1760649405_aa1ffc47fc316cd9.jpg','2025-10-16 21:16:45',8,NULL),(11,'Luz','2000-02-12',NULL,'Pendiente','uploads/comprobantes/comp_1760649744_13c28ec4201e7779.jpg','2025-10-16 21:22:24',8,NULL),(12,'Agua','2000-02-12',NULL,'Pendiente','uploads/comprobantes/comp_1760652322_cc140b966001e8bc.jpg','2025-10-16 22:05:22',8,NULL);
/*!40000 ALTER TABLE `comprobante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comprobantes_pago`
--

DROP TABLE IF EXISTS `comprobantes_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comprobantes_pago` (
  `id_Comprobante` int NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Monto` decimal(10,2) DEFAULT NULL,
  `Estado` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pendiente',
  `Archivo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha_Subida` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_Residente` int NOT NULL,
  `id_Administrador` int DEFAULT NULL,
  PRIMARY KEY (`id_Comprobante`),
  KEY `fk_comp_res` (`id_Residente`),
  KEY `fk_comp_admin` (`id_Administrador`),
  CONSTRAINT `fk_comp_admin` FOREIGN KEY (`id_Administrador`) REFERENCES `administrador` (`id_Administrador`) ON DELETE SET NULL,
  CONSTRAINT `fk_comp_res` FOREIGN KEY (`id_Residente`) REFERENCES `residente` (`id_Residente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comprobantes_pago`
--

LOCK TABLES `comprobantes_pago` WRITE;
/*!40000 ALTER TABLE `comprobantes_pago` DISABLE KEYS */;
INSERT INTO `comprobantes_pago` VALUES (1,'Factura','2025-09-12',900.00,'Pendiente','uploads/comprobantes/comp_1757702142_Repartido_pr__ctico__Funciones_compuestas__1_.pdf','2025-09-12 15:35:42',6,NULL),(2,'Factuara','2025-09-12',2232.00,'Aprobado','uploads/comprobantes/comp_1757709519_Soprano_cute_kitten.jpeg','2025-09-12 17:38:39',7,NULL),(3,'Factura','2025-09-12',222.00,'Aprobado','uploads/comprobantes/comp_1757709555_pichu.png','2025-09-12 17:39:15',7,NULL),(4,'F','2025-09-12',3232.00,'Aprobado','uploads/comprobantes/comp_1757709581_Proyecto_de_Pasaje_de_Grado_-_2025_2.pdf','2025-09-12 17:39:41',7,NULL),(5,'Factura','2025-09-12',555.00,'Pendiente','uploads/comprobantes/comp_1757709706_premium_photo-1681487178876-a1156952ec60.jpeg','2025-09-12 17:41:46',6,NULL),(6,'Factura','2025-09-12',345.00,'Pendiente','uploads/comprobantes/comp_1757711405_Repartido_pr__ctico__Funciones_compuestas__1_.pdf','2025-09-12 18:10:05',6,NULL),(7,'Agua','2000-02-12',1231.00,'Aprobado','uploads/comprobantes/comp_1760731244_c385e40cbaf98b0c.jpg','2025-10-17 20:00:44',9,NULL);
/*!40000 ALTER TABLE `comprobantes_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comunicados`
--

DROP TABLE IF EXISTS `comunicados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comunicados` (
  `Id_Aviso` int NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha` datetime DEFAULT CURRENT_TIMESTAMP,
  `Destinatario` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Contenido` text COLLATE utf8mb4_general_ci,
  `id_Administrador` int DEFAULT NULL,
  PRIMARY KEY (`Id_Aviso`),
  KEY `id_Administrador` (`id_Administrador`),
  CONSTRAINT `comunicados_ibfk_1` FOREIGN KEY (`id_Administrador`) REFERENCES `administrador` (`id_Administrador`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comunicados`
--

LOCK TABLES `comunicados` WRITE;
/*!40000 ALTER TABLE `comunicados` DISABLE KEYS */;
INSERT INTO `comunicados` VALUES (1,'holahola','2025-10-17 20:00:06',NULL,'asdasdads',2);
/*!40000 ALTER TABLE `comunicados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horas_trabajo`
--

DROP TABLE IF EXISTS `horas_trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `horas_trabajo` (
  `id_Hora` int NOT NULL AUTO_INCREMENT,
  `id_Residente` int NOT NULL,
  `Fecha` date NOT NULL,
  `Cantidad` decimal(5,2) NOT NULL,
  `Descripcion` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Fecha_Registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Hora`),
  KEY `fk_horas_res` (`id_Residente`),
  CONSTRAINT `fk_horas_res` FOREIGN KEY (`id_Residente`) REFERENCES `residente` (`id_Residente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horas_trabajo`
--

LOCK TABLES `horas_trabajo` WRITE;
/*!40000 ALTER TABLE `horas_trabajo` DISABLE KEYS */;
INSERT INTO `horas_trabajo` VALUES (1,6,'2025-09-12',67.00,'Limpieza','2025-09-12 15:35:31'),(2,7,'2025-09-12',43.00,'Limpieza','2025-09-12 17:38:21');
/*!40000 ALTER TABLE `horas_trabajo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `Id_Pagos` int NOT NULL AUTO_INCREMENT,
  `Monto` decimal(10,2) NOT NULL,
  `Medio` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Fecha` datetime DEFAULT CURRENT_TIMESTAMP,
  `Estado` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_Residente` int DEFAULT NULL,
  PRIMARY KEY (`Id_Pagos`),
  KEY `id_Residente` (`id_Residente`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`id_Residente`) REFERENCES `residente` (`id_Residente`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postulante`
--

DROP TABLE IF EXISTS `postulante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postulante` (
  `id_Postulante` int NOT NULL AUTO_INCREMENT,
  `Usuario` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Contrasena` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Nombre` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Apellido` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Correo` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Telefono` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Fecha_Registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_Vivienda` int DEFAULT NULL,
  PRIMARY KEY (`id_Postulante`),
  UNIQUE KEY `Usuario` (`Usuario`),
  UNIQUE KEY `Correo` (`Correo`),
  KEY `id_Vivienda` (`id_Vivienda`),
  CONSTRAINT `postulante_ibfk_1` FOREIGN KEY (`id_Vivienda`) REFERENCES `vivienda` (`id_Vivienda`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postulante`
--

LOCK TABLES `postulante` WRITE;
/*!40000 ALTER TABLE `postulante` DISABLE KEYS */;
/*!40000 ALTER TABLE `postulante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reclamos`
--

DROP TABLE IF EXISTS `reclamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reclamos` (
  `Id_Reclamo` int NOT NULL AUTO_INCREMENT,
  `Descripcion` text COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha` datetime DEFAULT CURRENT_TIMESTAMP,
  `Prioridad` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Estado` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_Residente` int DEFAULT NULL,
  PRIMARY KEY (`Id_Reclamo`),
  KEY `id_Residente` (`id_Residente`),
  CONSTRAINT `reclamos_ibfk_1` FOREIGN KEY (`id_Residente`) REFERENCES `residente` (`id_Residente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reclamos`
--

LOCK TABLES `reclamos` WRITE;
/*!40000 ALTER TABLE `reclamos` DISABLE KEYS */;
INSERT INTO `reclamos` VALUES (1,'holahola','2025-10-17 01:33:53',NULL,'Pendiente',8),(2,'holaholaholaholaholaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','2025-10-17 01:35:53',NULL,'Pendiente',8),(18,'asdasd','2025-10-17 04:40:24',NULL,'Pendiente',8),(19,'asdasdasd','2025-10-17 04:40:32',NULL,'Pendiente',8),(20,'asdasd','2025-10-17 04:50:00',NULL,'Pendiente',8),(81,'asdasdasdasd','2025-10-17 20:00:23',NULL,'abierto',9);
/*!40000 ALTER TABLE `reclamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residente`
--

DROP TABLE IF EXISTS `residente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `residente` (
  `id_Residente` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Cedula` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Correo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `id_Vivienda` int DEFAULT NULL,
  `Contrasena` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_aprobacion` tinyint(1) DEFAULT '0',
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `Usuario` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_Residente`),
  UNIQUE KEY `Correo` (`Correo`),
  UNIQUE KEY `uniq_residente_correo` (`Correo`),
  UNIQUE KEY `Cedula` (`Cedula`),
  UNIQUE KEY `Usuario` (`Usuario`),
  KEY `id_Vivienda` (`id_Vivienda`),
  CONSTRAINT `fk_res_vivienda` FOREIGN KEY (`id_Vivienda`) REFERENCES `vivienda` (`id_Vivienda`) ON DELETE SET NULL,
  CONSTRAINT `residente_ibfk_1` FOREIGN KEY (`id_Vivienda`) REFERENCES `vivienda` (`id_Vivienda`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residente`
--

LOCK TABLES `residente` WRITE;
/*!40000 ALTER TABLE `residente` DISABLE KEYS */;
INSERT INTO `residente` VALUES (6,'Santiago','mora','1234654223','matateporte@gmail.com','12312312','2132-03-12',NULL,'$2y$10$/N8kHg9fRTwqfJgr0BYTKeFkBhNZ5DeEtchl7PGHJ71ggESf6U03G',1,'2025-09-12 15:04:08','matateporte@gmail.com'),(7,'Santiago','mora','092392','santiago@gmail.com','3423423423','2025-09-12',NULL,'$2y$10$BSlsWfyUKN1Rg0/GPyTdIeHPhwH2cvZC2HB60tWnEmxcAH6JYbEu2',1,'2025-09-12 17:37:43',NULL),(8,'NicolÃ¡s','Pereyra','-','pereyranicolas417@gmail.com','-','2025-10-16',NULL,'$2y$10$u4N9GcLbUXdtmCNUD82Cee8ja86A4O1I8S0Ce99a709iCsjQY4RWO',1,'2025-10-16 20:19:07',NULL),(9,'Admin','Backoffice',NULL,'admin@fans.test',NULL,'2025-10-17',NULL,'$2y$10$dummyhashdummyhashdummyhashdummyhashdu',1,'2025-10-17 19:14:55',NULL);
/*!40000 ALTER TABLE `residente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@fans.test','$2y$10$jao1gzh6s7cNaGxm6LJL7.O.MW5mNRuc2jnsHXupspSFcwP15VB5S','admin','2025-10-15 03:57:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vivienda`
--

DROP TABLE IF EXISTS `vivienda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vivienda` (
  `id_Vivienda` int NOT NULL AUTO_INCREMENT,
  `Numero` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Direccion` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Tipo` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Estado` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_Administrador` int DEFAULT NULL,
  PRIMARY KEY (`id_Vivienda`),
  UNIQUE KEY `Numero` (`Numero`),
  KEY `id_Administrador` (`id_Administrador`),
  CONSTRAINT `vivienda_ibfk_1` FOREIGN KEY (`id_Administrador`) REFERENCES `administrador` (`id_Administrador`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vivienda`
--

LOCK TABLES `vivienda` WRITE;
/*!40000 ALTER TABLE `vivienda` DISABLE KEYS */;
/*!40000 ALTER TABLE `vivienda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fans_cooperativa'
--

--
-- Final view structure for view `Administrador`
--

/*!50001 DROP VIEW IF EXISTS `Administrador`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Administrador` AS select `administrador`.`id_Administrador` AS `id_Administrador`,`administrador`.`Nombre` AS `Nombre`,`administrador`.`Apellido` AS `Apellido`,`administrador`.`Usuario` AS `Usuario`,`administrador`.`Correo` AS `Correo`,`administrador`.`Contrasena` AS `Contrasena`,`administrador`.`estado_aprobacion` AS `estado_aprobacion`,`administrador`.`fecha_registro` AS `fecha_registro` from `administrador` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-17 20:34:39
